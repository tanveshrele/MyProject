$(document).ready(function(){
  $('#birth-date').mask('00/00/0000');
  /*$('#birth-date').datepicker({
    autoclose:true,
    todayHighlight:true
  }).datepicker('update',new Date())*/
  $('#phone-number').mask('00000-00000')
 });